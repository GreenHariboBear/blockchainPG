

package main


import (
	"fmt"
	"strconv"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"
)


// Chaincode implementation
type Coordinator struct {
	f1,f2,f3 bool;//init  false
	x1_val,x2_val,x3_val,Lambda float64;//initially they are zero
}



func (t *Coordinator) Init(stub shim.ChaincodeStubInterface) pb.Response {
	fmt.Println("ex02 Init")
     var err error
	// Get the function and arguments from the request
	function, _ := stub.GetFunctionAndParameters()
	
		// Check if the request is the init function
		if function != "init" {
			return shim.Error("Unknown function call")
		}
	
		if err != nil {
			return shim.Error(err.Error())
		}
	
	fmt.Printf("Lambda = %f\n" , t.Lambda)
	return shim.Success(nil)
}


func (t *Coordinator) Invoke(stub shim.ChaincodeStubInterface) pb.Response {
	//fmt.Println("ex02 invoke")
	function, args := stub.GetFunctionAndParameters()
    if function == "query" {
		 //the old "Query" is now implemtned in invoke
		return t.query(stub, args)
           }else if  function == "writeX_1" {
	
              return t.writeX_1(stub, args)

                } else if function == "writeX_2" {
	
          return t.writeX_2(stub, args)
                }else if function == "writeX_3" {
	
          return t.writeX_3(stub, args)
      }else if function == "ComputLamb" {
		
			  return t.ComputLamb(stub, args)
		  }
	return shim.Error("Invalid invoke function name. Expecting \"invoke\" \"write\" \"query\"")
}

func (t *Coordinator) writeX_1(stub shim.ChaincodeStubInterface, args []string) pb.Response {

	var flag1 bool// Asset holdings
	   // Entities
    var x_1 string// Asset holdings
	var plant1 float64
    //var isUpdat bool
	
	flag1=t.f1
	if flag1==false{
	x_1 = args[0]
	plant1,_= strconv.ParseFloat(string(args[1]),64)
	_= stub.PutState(x_1, []byte(strconv.FormatFloat(plant1,'f',5,64)))
	t.f1 = true
	t.x1_val=plant1
	//fmt.Printf("plant1 = %f\n" , t.x1_val)
	fmt.Println("Plant_1 is uptated")
	} 
	

	return shim.Success(nil)
}
func (t *Coordinator) writeX_2(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	    var flag2 bool// Asset holdings
	    var   x_2 string// Entities
		//var x1_val,x2_val,x3_val float64 // Asset holdings
	
	  var plant2 float64
		
		//var Lambda  float64
		//var isUpdat bool
		
		flag2 = t.f2
   if flag2==false {
	    x_2= args[0]
		plant2,_= strconv.ParseFloat(string(args[1]),64)
		t.x2_val=plant2
		_= stub.PutState(x_2, []byte(strconv.FormatFloat(plant2,'f',5,64)))
		 
		t.f2 = true
		//fmt.Printf("plant2 = %f\n" , t.x2_val)
		fmt.Println("Plant_2 is uptated")
   }
	

		
 return shim.Success(nil)
		
}

func (t *Coordinator) writeX_3(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	 
	var flag3 bool// Asset holdings
	 var x_3 string  // Entities
	//var x1_val,x2_val,x3_val float64 // Asset holdings
	var plant3 float64
    //var err error
	
//	var Lambda  float64
//var isUpdat bool
	
	flag3=t.f3
	if flag3 == false{
	x_3= args[0]
	plant3,_= strconv.ParseFloat(string(args[1]),64)
	t.x3_val=plant3
    _= stub.PutState(x_3, []byte(strconv.FormatFloat(plant3,'f',5,64)))
	 t.f3=true
	 
	// fmt.Printf("plant3 = %f\n" , t.x3_val)
	 fmt.Println("Plant_3 is uptated")
	} 
  
 return shim.Success(nil)
}	

 
func (t *Coordinator) ComputLamb(stub shim.ChaincodeStubInterface, args []string) pb.Response {

 var isUpdat bool
 var L,x_1,x_2,x_3 string
isUpdat = t.f1 && t.f2 && t.f3
if isUpdat==true {
  
t.Lambda = t.Lambda + 0.5 *( t.x1_val + t.x2_val + t.x3_val)
	
// Write the state back to the ledge
  
   fmt.Printf("Plant1_val = %f\n,Plant2_val = %f\n,Plant3_val = %f\n", t.x1_val,t.x2_val,t.x3_val )
   fmt.Printf("NeWLambda = %f\n" , t.Lambda)
   _ = stub.PutState(L, []byte(strconv.FormatFloat(t.Lambda,'f',5,64)))
   _ = stub.PutState(x_1, []byte(strconv.FormatFloat(t.x1_val,'f',5,64)))
   _ = stub.PutState(x_2, []byte(strconv.FormatFloat(t.x2_val,'f',5,64)))
   _ = stub.PutState(x_3, []byte(strconv.FormatFloat(t.x3_val,'f',5,64)))
   t.f1=false;t.f2=false;t.f3=false

}
return shim.Success(nil)
}
// query callback representing the query of a chaincode
func (t *Coordinator) query(stub shim.ChaincodeStubInterface, args []string) pb.Response {
 	var L string // Entities
    var err error

	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting name of the company to query")
	}

	L = args[0]

	// Get the Updated lambda from the ledger
	Lambdabytes, err := stub.GetState(L)
	if err != nil {
		jsonResp := "{\"Error\":\"Failed to get state for " + L + "\"}"
		return shim.Error(jsonResp)
	}

	if Lambdabytes == nil {
		jsonResp := "{\"Error\":\"Nil amount for " + L + "\"}"
		return shim.Error(jsonResp)
	}

	jsonResp := "{\"Name\":\"" + L + "\",\"Amount\":\"" + string(Lambdabytes) + "\"}"
	fmt.Printf("Query Response:%s\n", jsonResp)
	return shim.Success(Lambdabytes)
}

func main() {
	err := shim.Start(new(Coordinator))
	if err != nil {
		fmt.Printf("Error starting Coordinator: %s", err)
	}
	 
}